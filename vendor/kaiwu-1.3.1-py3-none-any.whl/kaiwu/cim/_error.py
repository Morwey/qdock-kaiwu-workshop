# -*- coding: utf-8 -*-
"""
模块: CIM

功能: CIM相关的错误处理
"""
from kaiwu.core import KaiwuError

ERROR_CODE = {}


class CIMError(KaiwuError):
    """Exceptions in qubo module."""

    def __init__(self, error_info):
        self.error_info = error_info

    def __str__(self):
        return self.error_info
