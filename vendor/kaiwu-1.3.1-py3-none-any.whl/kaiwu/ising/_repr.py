# -*- coding: utf-8 -*-
"""
模块: cim

功能: 提供Ising相关类的字符串转化
"""


def _dict_variables(var_dict):
    var_list = [0] * len(var_dict)
    for var in var_dict:
        var_list[var_dict[var]] = var[1:]
    return str(tuple(var_list)).replace("\'", "")[1:-1]


if __name__ == '__main__':
    import doctest
    doctest.testmod()
