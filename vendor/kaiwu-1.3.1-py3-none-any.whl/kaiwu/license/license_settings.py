"""
光量子计算云平台国内版license配置-生产环境
"""
# pylint: disable=<R0801>
# 平台域名
PLATFORM_DOMAIN = "platform.qboson.com"
# 接口地址
KDEV_URL = 'https://platform.qboson.com/'
# 网关域名
GATEWAY_DOMAIN_NAME = 'https://new-open.qboson.com'
# 签名密钥
SECRET_KEY = b'-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx9M/LYmr9kbo1yuC5v' \
             b'OJ\nWDrPupdJ0UN+gct7N7thY/Ghnqy4menAHTXpYQmSrsUUIHFxN3dVV25d81wTQ32w\nTRzBi7i4+f2tOlnCkDNwgkeIsYf' \
             b'5imYOyY3mPdRF2WwCF63fbjlkUqVqWckjNhLz\nAbXKpAV+JqZu2hD79Di4Au+1c9LSpfzLU3hwz4qKM0He6eUwjP6EEW5' \
             b'4982Um+ry\nF6V0mijHtZpQev8fSqfezgwV9Wn1ZKurl0H97ZVpISGrZDdFFKCpt45i4gLM4LCt\nkY4a4kN23egM6ctw0M2O' \
             b'O1EYzTl0Uw3EXYU9Q2Y4126q9F6l6UbGavWHXB6kGtdR\n6wIDAQAB\n-----END PUBLIC KEY-----\n'
# 加密算法
ALGORITHM = 'RS256'
