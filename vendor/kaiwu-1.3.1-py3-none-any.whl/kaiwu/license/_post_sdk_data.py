"""
统计SDK使用情况的一些工具
"""
from enum import Enum
from urllib.parse import urljoin
import requests
from kaiwu.license._license_utils import _read_license
from kaiwu.license.license_settings import KDEV_URL

# sdk_data接口url
SDK_DATA_URL = urljoin(KDEV_URL, '/kdev/sdk-data/')


class TaskStatus(Enum):
    """
    任务状态
    """
    START_CALL = 1  # 开始调用
    END_CALL = 2  # 调用成功
    EXCEPTION_CALL = 3  # 调用异常


def post_sdk_data(uid, alg_name, task_status=TaskStatus.START_CALL, error_info=""):
    """
    向api/sdk_data/发送数据

    :param uid: 问题唯一标识
    :param alg_name: 算法名称
    :param task_status: 函数调用阶段，1-开始调用，2-调用成功，3-调用异常
    :param error_info: 错误信息

    发送数据格式
    Json
    {
        'user_id': 2196275214680305   # 用户身份标识
        'sdk_code': "8imoHjfd2qiR5bUES13FO5PB4hQYEy"   # sdk授权码
        'task_id': "d2b0406c-301f-11ee-bdaa-6479f07095d0"   # 问题唯一标识uuid
        "is_statistics": False
        'alg_name': "cim"   # 算法名称
        'task_status': 1  # 函数调用阶段，1-开始调用，2-调用成功，3-调用异常
        'bit_count': 30    # 比特数
        'error_info': ""    # 错误信息
    }

    """
    try:
        # 获取license
        decrypted_message, sdk_code = _read_license()

        if "is_statistics" in decrypted_message and not decrypted_message.get('is_statistics'):
            return

        # 获取user_id 和 比特数
        user_id = decrypted_message.get('user_id')
        bit_count = decrypted_message.get('qubits')
        task_id = str(uid)

        data = {'user_id': user_id,
                'sdk_code': sdk_code,
                'task_id': task_id,
                'alg_name': alg_name,
                'task_status': task_status.value,
                'bit_count': bit_count,
                'error_info': error_info}
        requests.post(
            url=SDK_DATA_URL,
            headers={"Content-Type": "application/json"},
            json=data,
            timeout=10
        )

        # requests.post(url=SDK_DATA_URL, headers={"Content-Type": "application/json"}, json=data, timeout=10)
    except:
        pass
