"""
光量子计算云平台-测试环境license配置
"""
# 平台域名
PLATFORM_DOMAIN = "10.0.0.241:80"
# 接口地址
KDEV_URL = 'http://10.0.0.241:7000'
# 签名密钥
SECRET_KEY = 'django-insecure-u_$ei@^s&#)lrol)w58n9@dyq7!s6$b_7e_^g3@#mj%srnc-ms'
# 加密算法
ALGORITHM = 'HS256'
# 网关域名
GATEWAY_DOMAIN_NAME = 'http://env-ctpoqvem1hkl3h40mqc0-cn-beijing-vpc.alicloudapi.com'
