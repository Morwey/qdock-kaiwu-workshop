"""
光量子计算云平台-测试环境license配置
"""
# 平台域名
PLATFORM_DOMAIN = "127.0.0.1:80"
# 接口地址
KDEV_URL = 'http://127.0.0.1:8000'
# 签名密钥
SECRET_KEY = '1123234-1213-u_$ei@^s&#)lrol)w58n9@dyq7331!s6$b_7e1_^g3@#mj%srnc-ms'
# 加密算法
ALGORITHM = 'HS256'
# 网关域名
GATEWAY_DOMAIN_NAME = 'http://127.0.0.1:8000'
