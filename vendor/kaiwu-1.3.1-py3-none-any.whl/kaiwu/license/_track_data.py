"""
用户使用习惯跟踪
"""
import threading
import uuid
from functools import wraps
from kaiwu.license._post_sdk_data import post_sdk_data, TaskStatus


def track_data(alg_name=None, enabled=False):
    """
    数据追踪装饰器
    """

    def decorator(func):
        if not enabled:
            return func

        @wraps(func)
        def wrapper(*args, **kwargs):
            # 生成 alg_name
            if alg_name:
                generated_alg_name = alg_name
            else:
                module_name = func.__module__.split('.')[-1]
                qualname_parts = func.__qualname__.split('.')
                if len(qualname_parts) > 1:
                    class_name = qualname_parts[-2]
                    func_name = qualname_parts[-1]
                    generated_alg_name = f"{module_name}.{class_name}.{func_name}"
                else:
                    func_name = qualname_parts[0]
                    generated_alg_name = f"{module_name}.{func_name}"

            uid = uuid.uuid1()

            # 启动后台线程发送 START_CALL
            threading.Thread(
                target=post_sdk_data,
                args=(uid, generated_alg_name, TaskStatus.START_CALL, "")
            ).start()

            try:
                result = func(*args, **kwargs)
                # 启动后台线程发送 END_CALL
                threading.Thread(
                    target=post_sdk_data,
                    args=(uid, generated_alg_name, TaskStatus.END_CALL, "")
                ).start()
                return result
            except Exception as exc:
                # 启动后台线程发送 EXCEPTION_CALL
                threading.Thread(
                    target=post_sdk_data,
                    args=(uid, generated_alg_name, TaskStatus.EXCEPTION_CALL, str(exc))
                ).start()
                raise

        return wrapper

    return decorator
