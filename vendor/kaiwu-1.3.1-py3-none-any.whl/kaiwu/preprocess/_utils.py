# -*- coding: utf-8 -*-
"""
模块: dynamic_range

功能: 局部赋值
"""
import numpy as np

from kaiwu.license import track_data


def _partial_assignment(ising_mat, indices, values):
    """
    抽取变量，生成subQUBO对应的子矩阵
    Args:

        ising_mat: Ising矩阵, 必须是对称矩阵，否则会出现错误

        indices: 赋值变量

        values: 为变量所赋的值，只能为0或1

    Returns:
        sub_mat, bias(tuple)： sub_mat为被赋值变量固定后的矩阵，bias为产生的偏置项
    """
    indices = np.array(indices)
    values = np.array(values)

    sub_size = ising_mat.shape[0] - indices.shape[0]
    sub_index = np.array([i for i in range(ising_mat.shape[0]) if i not in indices])
    sub_mat = np.zeros((sub_size + 1, sub_size + 1))
    sub_mat[:sub_size, :sub_size] = ising_mat[np.ix_(sub_index, sub_index)]
    solution_clamp = np.zeros(ising_mat.shape[0])
    solution_clamp[indices] = values

    c_linear = ising_mat.dot(solution_clamp)
    bias = solution_clamp.dot(c_linear)
    c_linear = c_linear[sub_index]

    sub_mat[-1, :sub_size] = c_linear
    sub_mat[:sub_size, -1] = c_linear
    return sub_mat, bias


@track_data()
def get_min_diff(mat):
    """计算最小差值

    Args:
        mat: Ising或QUBO矩阵

    Returns:
        float: 最小差值

    Examples:
        >>> import numpy as np
        >>> mat = np.array([[0, 8, 1 ,1],
        ...                 [0, 0, 2, -1],
        ...                 [0, 0, 0, -8],
        ...                 [0, 0, 0, 0]])
        >>> import kaiwu as kw
        >>> kw.preprocess.get_min_diff(mat)
        np.int64(1)
    """
    params = np.unique(mat)  # <- doing this includes 0; result is sorted
    return np.diff(params).min()


@track_data()
def get_dynamic_range_metric(mat):
    """计算动态范围值（dynamic range, DR）

    :math:`DR(Q) = log(max_{i,j}|Q_i - Q_j|/min_{Q_i \\neq Q_j}|Q_i-Q_j|)`

    Args:
        mat: Ising或QUBO矩阵

    Returns:
        float: 动态范围

    Examples:
        >>> import numpy as np
        >>> mat = np.array([[0, 8, 1 ,1],
        ...                 [0, 0, 2, -1],
        ...                 [0, 0, 0, -8],
        ...                 [0, 0, 0, 0]])
        >>> import kaiwu as kw
        >>> kw.preprocess.get_dynamic_range_metric(mat)
        np.float64(4.0)
    """
    return _get_dynamic_range_metric(mat)


def _get_dynamic_range_metric(mat):
    """计算动态范围值（dynamic range, DR）"""
    params = np.unique(mat)  # <- doing this includes 0; result is sorted
    max_diff = params[-1] - params[0]
    min_diff = np.diff(params).min()
    return np.log2(max_diff / min_diff)


if __name__ == '__main__':
    import doctest

    doctest.testmod()
