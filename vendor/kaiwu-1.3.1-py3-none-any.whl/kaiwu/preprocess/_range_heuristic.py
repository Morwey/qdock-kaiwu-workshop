# -*- coding: utf-8 -*-
"""
模块: dynamic_range

功能: 提供选择系数变化量的启发式算法
"""
import numpy as np


class Greedy:
    """贪心算法"""

    @staticmethod
    def compute_change(matrix_order, i, j, increase=True):
        """根据贪心法的变化范围确定变化量"""
        sorted_index = matrix_order.get_sorted_index(i, j)
        n_unique = matrix_order.num_unique
        sorted_elem = matrix_order.unique
        second_min_distance = matrix_order.second_min_distance
        if sorted_index == 0:
            if matrix_order.min_index_lower == sorted_index and not np.isclose(second_min_distance,
                                                                               matrix_order.min_distance):
                change = sorted_elem[n_unique - 1] - 2 * sorted_elem[0] + sorted_elem[1] + \
                         matrix_order.extra_summand
            else:
                change = sorted_elem[n_unique - 1] - 2 * sorted_elem[0] + sorted_elem[1]
        elif sorted_index == n_unique - 1:
            if matrix_order.min_index_lower + 1 == sorted_index and not np.isclose(second_min_distance,
                                                                                   matrix_order.min_distance):
                change = sorted_elem[0] - 2 * sorted_elem[n_unique - 1] + \
                         sorted_elem[n_unique - 2] - matrix_order.extra_summand
            else:
                change = sorted_elem[0] - 2 * sorted_elem[n_unique - 1] + sorted_elem[n_unique - 2]
        else:
            if increase:
                if matrix_order.min_index_lower == sorted_index and not np.isclose(second_min_distance,
                                                                                   matrix_order.min_distance):
                    change = sorted_elem[n_unique - 1] - sorted_elem[sorted_index] + matrix_order.extra_summand
                else:
                    change = sorted_elem[n_unique - 1] - sorted_elem[sorted_index] - matrix_order.min_distance
            else:
                if matrix_order.min_index_lower + 1 == sorted_index and not np.isclose(second_min_distance,
                                                                                       matrix_order.min_distance):
                    change = sorted_elem[1] - sorted_elem[sorted_index] - matrix_order.extra_summand
                else:
                    change = sorted_elem[1] - sorted_elem[sorted_index] + matrix_order.min_distance
        return change

    @staticmethod
    def decide_increase(matrix_order, i, j):
        """决定元素值变化方向"""
        sorted_index = matrix_order.get_sorted_index(i, j)
        increase = matrix_order.unique[sorted_index] < 0
        return increase


class MaintainOrder:
    """系数在变化时保持相对顺序不变"""

    @staticmethod
    def compute_change(matrix_order, i, j, increase=True):
        """确定元素值变化量"""
        sorted_index = matrix_order.get_sorted_index(i, j)
        n_unique = matrix_order.num_unique
        sorted_elem = matrix_order.unique
        if sorted_index == 0:
            if increase:
                change = sorted_elem[1] - sorted_elem[0] - matrix_order.min_distance
            else:
                change = - matrix_order.extra_summand
        elif sorted_index == n_unique - 1:
            if increase:
                change = matrix_order.extra_summand
            else:
                change = sorted_elem[n_unique - 2] - sorted_elem[n_unique - 1] + \
                         matrix_order.min_distance
        else:
            current = sorted_elem[sorted_index]
            if increase:
                lower, upper = matrix_order.obtain_increase_bounds(sorted_index)
                mid = (upper - lower) / 2.0
                min_mat = min(upper - current, current - lower)
                change = mid - min_mat
            else:
                lower, upper = matrix_order.obtain_decrease_bounds(sorted_index)
                mid = (lower - upper) / 2.0
                min_mat = min(upper - current, current - lower)
                change = mid + min_mat
        return change

    @staticmethod
    def decide_increase(matrix_order, i, j):
        """决定元素值变化方向"""
        sorted_index = matrix_order.get_sorted_index(i, j)
        sorted_elem = matrix_order.unique
        if sorted_index == 0:
            second_min_distance = matrix_order.second_min_distance
            increase = matrix_order.min_index_lower != sorted_index or np.isclose(
                second_min_distance, matrix_order.min_distance)
        elif sorted_index == sorted_elem.shape[0] - 1:
            second_min_distance = matrix_order.second_min_distance
            increase = matrix_order.min_index_lower + 1 == sorted_index and not np.isclose(
                second_min_distance, matrix_order.min_distance)
        else:
            current = sorted_elem[sorted_index]
            lower, _ = matrix_order.obtain_decrease_bounds(sorted_index)
            _, upper = matrix_order.obtain_increase_bounds(sorted_index)
            increase = current - lower < upper - current
        return increase


class _MatrixOrder:
    """矩阵顺序。包括矩阵元素的值，顺序，以及在元素变化时维护信息"""

    def __init__(self, matrix, precision=8):
        self.precision = precision
        self.matrix = matrix
        self.matrix = np.round(self.matrix, decimals=self.precision)
        self.sorted = np.sort(self.matrix, axis=None)
        # 去除重复值，获得排序后的值、下标以及各值出现次数
        self.unique, self.indices, self.sorted_indices, self.counts = np.unique(self.matrix.flatten(),
                                                                                return_inverse=True, return_index=True,
                                                                                return_counts=True)
        self.distances = self.unique[1:] - self.unique[:-1]
        self.min_index_lower = np.argmin(self.distances)  # 距离最小值处下标
        self.min_distance = self.distances[self.min_index_lower]
        self.exclusive_min_distance = np.min(self.distances[self.distances > self.min_distance])
        self.second_min_distance = np.min(np.r_[self.distances[:self.min_index_lower],
        self.distances[self.min_index_lower + 1:]])
        self.extra_summand = self.exclusive_min_distance - self.min_distance
        self.dynamic_range = np.log2((self.unique[-1] - self.unique[0]) / self.min_distance)
        self.num_unique = len(self.unique)

    def update_entry(self, i, j, change):
        """改变一个元素，并重新计算相关信息
        返回：
            动态范围是否应该停止
        """
        if not isinstance(change, str):
            new_value = self.matrix[i, j] + change
        else:
            new_value = self.unique[int(change)]
        new_value = np.round(new_value, decimals=self.precision)
        self.matrix[i, j] = new_value
        self.sorted = np.sort(self.matrix, axis=None)
        self.unique, self.indices, self.sorted_indices, self.counts = np.unique(self.matrix.flatten(),
                                                                                return_inverse=True, return_index=True,
                                                                                return_counts=True)
        self.distances = self.unique[1:] - self.unique[:-1]
        self.min_index_lower = np.argmin(self.distances)
        self.min_distance = self.distances[self.min_index_lower]
        if not (self.distances > self.min_distance).any():  # 所有distance都为min_distance
            return True

        self.exclusive_min_distance = np.min(self.distances[self.distances > self.min_distance])
        self.second_min_distance = np.min(np.concatenate([
            self.distances[:self.min_index_lower],
            self.distances[self.min_index_lower + 1:]]))
        self.extra_summand = self.exclusive_min_distance - self.min_distance
        self.dynamic_range = np.log2((self.unique[-1] - self.unique[0]) / self.min_distance)
        self.num_unique = len(self.unique)
        return False

    def get_sorted_index(self, i, j):
        """使用矩阵下标访问"""
        return self.sorted_indices[i * self.matrix.shape[0] + j]

    def obtain_increase_bounds(self, sorted_index):
        """求保持原顺序情况下的增加范围"""
        upper_increase = self.unique[sorted_index + 1]
        if self.counts[sorted_index] > 1:
            lower_increase = self.unique[sorted_index]
        else:
            lower_increase = self.unique[sorted_index - 1]
        return lower_increase, upper_increase

    def obtain_decrease_bounds(self, sorted_index):
        """求保持原顺序情况下的减少范围"""
        lower_decrease = self.unique[sorted_index - 1]
        print(lower_decrease)
        if self.counts[sorted_index] > 1:
            upper_decrease = self.unique[sorted_index]
        else:
            upper_decrease = self.unique[sorted_index + 1]
        return lower_decrease, upper_decrease

    def dynamic_range_impact(self):
        """
        获得影响DR值计算的元素。
        :math:`DR = log(max_{i,j}|Q_i-Q_j|/min|Q_i-Q_j|)`,
        返回分子分母共四个元素。如果某个元素值重复出现，则不返回。
        """
        elems = []
        # add border elements for max D
        if self.counts[0] == 1:
            elems.append(self.indices[0])
        if self.counts[-1] == 1:
            elems.append(self.indices[-1])
        # add elements for min D
        dists = self.distances
        min_dist_indices = np.where(np.isclose(dists, self.min_distance))[0]
        for dist_index in min_dist_indices:
            if self.unique[dist_index] != 0:
                if self.counts[dist_index] == 1:
                    if self.indices[dist_index] not in elems:
                        elems.append(self.indices[dist_index])
            if self.unique[dist_index + 1] != 0:
                if self.counts[dist_index + 1] == 1:
                    if self.indices[dist_index + 1] not in elems:
                        elems.append(self.indices[dist_index + 1])
        return elems
